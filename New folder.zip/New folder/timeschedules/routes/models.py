from django.db import models

# Create your models here.
from django.db import models
class routes(models.Model):
    eid = models.CharField(max_length=100)
    edeparturename = models.CharField(max_length=100)
    edestinationname = models.CharField(max_length=100)
    edepartTime = models.CharField(max_length=15)
    class Meta:
        db_table = "Routes"
