from django import forms
from timeschedules.models import timeschedules
class routesForm(forms.ModelForm):
    class Meta:
        model = timeschedules
        fields = "__all__"